---
sidebar_position: 0
title: PSQI - Escala Completa em PDF, Pontuação e Interpretação
description: "Baixe gratuitamente o PSQI em PDF. Entenda como aplicar, calcular a pontuação e interpretar os resultados do Pittsburgh Sleep Quality Index."
keywords:
  - PSQI
  - PSQI PDF
  - Pittsburgh Sleep Quality Index
  - qualidade do sono
  - PSQI interpretação
  - PSQI pontuação
  - avaliação do sono
  - insônia
  - sono
---

# PSQI: Escala Completa em PDF, Pontuação e Interpretação

O **PSQI (Pittsburgh Sleep Quality Index)** é uma das escalas mais utilizadas mundialmente para avaliação da qualidade do sono.

O instrumento permite identificar dificuldades relacionadas ao sono e compreender como elas impactam o funcionamento diário do indivíduo.

Neste artigo você encontrará:

✅ O que é o PSQI

✅ Como aplicar a escala

✅ Como calcular a pontuação

✅ Como interpretar os resultados

✅ Download gratuito do PSQI em PDF

---

## Download Gratuito do PSQI em PDF

Precisa aplicar o PSQI em sua prática clínica?

👉 **[Baixar PSQI em PDF](URL_DO_PDF)**

---

## O que é o PSQI?

O Pittsburgh Sleep Quality Index (PSQI) é um instrumento desenvolvido para avaliar a qualidade do sono durante o último mês.

A escala investiga diferentes aspectos do sono, permitindo identificar dificuldades que muitas vezes passam despercebidas em uma entrevista clínica tradicional.

O instrumento é amplamente utilizado em:

- Psicologia;
- Psiquiatria;
- Medicina do Sono;
- Neurologia;
- Pesquisas científicas.

---

## Para que serve o PSQI?

O PSQI pode ser utilizado para:

- Avaliar a qualidade do sono;
- Identificar possíveis distúrbios do sono;
- Monitorar intervenções terapêuticas;
- Avaliar impacto do sono na rotina diária;
- Produzir indicadores objetivos de acompanhamento.

A escala não substitui avaliação médica especializada.

---

## O que o PSQI avalia?

O instrumento analisa sete componentes principais.

### Qualidade Subjetiva do Sono

Como a pessoa percebe a qualidade do próprio sono.

### Latência do Sono

Tempo necessário para adormecer.

### Duração do Sono

Quantidade média de horas dormidas.

### Eficiência Habitual do Sono

Relação entre tempo na cama e tempo efetivamente dormindo.

### Distúrbios do Sono

Interrupções, despertares e fatores que prejudicam o sono.

### Uso de Medicação

Frequência de utilização de medicamentos para dormir.

### Disfunção Diurna

Impacto do sono sobre energia, atenção e funcionamento durante o dia.

---

## Como funciona a pontuação do PSQI?

Cada componente recebe uma pontuação entre 0 e 3 pontos.

A soma dos componentes gera um escore global que varia de:

**0 a 21 pontos**

Quanto maior a pontuação, pior tende a ser a qualidade do sono.

---

## Como interpretar os resultados do PSQI?

### Pontuação Global

| Escore | Interpretação |
|----------|----------|
| 0 – 4 | Boa qualidade de sono |
| 5 – 10 | Qualidade de sono ruim |
| 11 – 21 | Distúrbio grave de sono |

---

### Qualidade Subjetiva do Sono

| Escore | Interpretação |
|----------|----------|
| 0 – 1 | Boa percepção do sono |
| 2 – 3 | Sono percebido como ruim |

---

### Latência do Sono

| Escore | Interpretação |
|----------|----------|
| 0 – 2 | Adormece com facilidade |
| 3 – 6 | Demora significativa para adormecer |

---

### Duração do Sono

| Escore | Interpretação |
|----------|----------|
| 0 – 1 | Duração adequada |
| 2 – 3 | Sono insuficiente |

---

### Distúrbios do Sono

| Escore | Interpretação |
|----------|----------|
| 0 – 4 | Poucas interrupções |
| 5 – 12 | Sono fragmentado |

---

### Disfunção Diurna

| Escore | Interpretação |
|----------|----------|
| 0 – 2 | Boa disposição |
| 3 – 6 | Sonolência e fadiga frequentes |

---

## O verdadeiro valor do PSQI está na evolução dos resultados

Uma única aplicação mostra apenas como o paciente dormiu no último mês.

Aplicações sucessivas permitem identificar:

- Melhora da qualidade do sono;
- Redução da latência para adormecer;
- Diminuição de despertares noturnos;
- Menor dependência de medicamentos;
- Redução da fadiga diurna.

![Acompanhamento longitudinal dos fatores do PSQI no eConsult](#)

*Exemplo ilustrativo de monitoramento longitudinal dos componentes da qualidade do sono ao longo do tratamento.*

### O que observar no PSQI?

O escore global é importante, mas os componentes costumam revelar informações clínicas ainda mais úteis.

Por exemplo:

- Latência elevada com duração adequada;
- Sono suficiente, porém pouco restaurador;
- Boa duração de sono com elevada sonolência diurna;
- Dependência crescente de medicamentos para dormir.

Essa análise ajuda a identificar padrões específicos que podem orientar intervenções mais precisas.

👉 Veja também: [Leitura evolutiva do caso](../../030-inteligencia-clinica/040-leitura-evolutiva-do-caso.md)

---

## Quando aplicar o PSQI?

### Avaliação inicial

Para compreender hábitos e qualidade do sono.

### Monitoramento clínico

Para acompanhar mudanças ao longo do tratamento.

### Casos de ansiedade e depressão

Quando o sono pode estar influenciando o quadro clínico.

### Intervenções focadas em higiene do sono

Para avaliar resultados de mudanças comportamentais.

---

## Vantagens do PSQI

- Forte respaldo científico;
- Fácil aplicação;
- Avaliação multidimensional;
- Excelente para monitoramento clínico;
- Amplamente utilizado internacionalmente;
- Boa sensibilidade para problemas relacionados ao sono.

---

## Limitações do PSQI

- Baseia-se em autorrelato;
- Não produz diagnóstico médico;
- Não substitui polissonografia;
- Deve ser interpretado juntamente com avaliação clínica.

---

## Download do PSQI em PDF

👉 **[Baixar PSQI em PDF](URL_DO_PDF)**

---

## Como o eConsult auxilia no acompanhamento clínico

Os problemas relacionados ao sono costumam mudar ao longo do tratamento.

Com o eConsult você pode:

- Aplicar escalas periodicamente;
- Registrar resultados automaticamente;
- Visualizar gráficos de evolução;
- Acompanhar componentes específicos do sono;
- Utilizar marcadores clínicos;
- Integrar resultados ao prontuário eletrônico.

👉 **Conheça o Sistema Clínico Longitudinal para Psicólogos:** https://econsult.app.br/sistema-clinico-longitudinal-psicologo

---

## Perguntas Frequentes sobre o PSQI

### O PSQI faz diagnóstico de insônia?

Não. O PSQI avalia qualidade do sono e auxilia no rastreamento de possíveis problemas.

### Qual a pontuação máxima do PSQI?

A pontuação máxima é de 21 pontos.

### Qual é o ponto de corte mais utilizado?

Pontuações acima de 5 geralmente indicam pior qualidade de sono.

### Existe versão do PSQI em PDF?

Sim. Você pode disponibilizar a escala em PDF para download neste artigo.

### O PSQI é validado para o Brasil?

Sim. Existe versão brasileira validada do instrumento.

### Qual a diferença entre PSQI e ESS?

O PSQI avalia a qualidade do sono. A ESS avalia a sonolência diurna excessiva.

:::tip Quer avaliar a sonolência durante o dia? Conheça a ESS.

👉 [**ESS**: Escala de Sonolência de Epworth](../040-sono/010-ess.md)

:::

---

## Artigos Relacionados

👉 [Quando aplicar avaliações psicológicas](../../040-guias/000-quando-aplicar-avaliacoes.md)

👉 [Como escolher uma escala psicológica](../../040-guias/010-como-escolher-uma-escala.md)

👉 [Interpretação de resultados](../../040-guias/020-interpretacao-de-resultados.md)

👉 [Observação clínica vs observação estruturada](../../050-comparativos/040-observacao-clinica-vs-observacao-estruturada.md)

👉 [Dados isolados vs leitura evolutiva do caso](../../050-comparativos/050-dados-isolados-vs-leitura-evolutiva-do-caso.md)

👉 [Sugestão inteligente de avaliações](../../030-inteligencia-clinica/040-sugestao-inteligente-de-avaliacoes.md)

👉 [Leitura evolutiva do caso](../../030-inteligencia-clinica/030-leitura-evolutiva-do-caso.md)

---

## Referências

BUYSSE, D. J.; REYNOLDS III, C. F.; MONK, T. H.; BERMAN, S. R.; KUPFER, D. J. *The Pittsburgh Sleep Quality Index: A new instrument for psychiatric practice and research*. Psychiatry Research, 1989.

BERTOLAZI, A. N.; et al. *Validation of the Brazilian Portuguese version of the Pittsburgh Sleep Quality Index (PSQI-BR)*. Sleep Medicine, 2011.