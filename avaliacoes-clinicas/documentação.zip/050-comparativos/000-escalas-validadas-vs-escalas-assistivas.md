---
sidebar_position: 0
title: Escalas Validadas vs Escalas Assistivas
description: "Entenda as diferenças entre avaliações científicas validadas e escalas assistivas voltadas ao acompanhamento clínico longitudinal."
---

# Escalas Validadas vs Escalas Assistivas

***📊 DIFERENTES INSTRUMENTOS PARA DIFERENTES OBJETIVOS CLÍNICOS***

Profissionais que começam a utilizar avaliações clínicas frequentemente se deparam com uma dúvida importante:

> Qual a diferença entre uma avaliação científica validada e uma escala assistiva?

A resposta é simples:

Embora ambas possam contribuir para o acompanhamento clínico, elas possuem finalidades diferentes.

Enquanto as avaliações validadas procuram medir construtos específicos por meio de instrumentos desenvolvidos e estudados cientificamente, as escalas assistivas procuram estruturar observações relevantes do processo terapêutico ao longo do tempo.

Não se trata de escolher uma ou outra.

Em muitos casos, elas podem atuar de forma complementar.

---

## O que são escalas validadas?

Escalas validadas são instrumentos desenvolvidos por meio de pesquisas científicas e submetidos a processos de validação metodológica.

Seu objetivo é avaliar construtos específicos de forma padronizada.

Exemplos:

* PHQ-9
* GAD-7
* DASS-21
* SRQ-20
* WHOQOL-BREF
* AUDIT

Esses instrumentos podem auxiliar na observação de aspectos como:

* sintomas depressivos
* ansiedade
* sofrimento psicológico
* qualidade de vida
* uso de substâncias
* funcionalidade

---

## O que são escalas assistivas?

Escalas assistivas são instrumentos estruturados para apoiar o acompanhamento clínico longitudinal.

Seu objetivo não é realizar diagnósticos nem substituir avaliações científicas.

Elas auxiliam na organização de observações clínicas relevantes ao longo do processo terapêutico.

Exemplos:

* Engajamento Terapêutico
* Risco de Abandono
* Direção Clínica
* Aliança Terapêutica
* Estágio do Processo Terapêutico
* Risco Clínico Dinâmico

Esses instrumentos ajudam a acompanhar aspectos que normalmente aparecem apenas em registros narrativos.

---

## Comparando os dois modelos

| Aspecto                            | Escalas Validadas            | Escalas Assistivas              |
| ---------------------------------- | ---------------------------- | ------------------------------- |
| Base científica                    | Sim                          | Estrutura assistiva             |
| Objetivo principal                 | Medir construtos específicos | Estruturar observações clínicas |
| Diagnóstico                        | Não substituem diagnóstico   | Não realizam diagnóstico        |
| Aplicação                          | Avaliação e monitoramento    | Acompanhamento longitudinal     |
| Comparação temporal                | Sim                          | Sim                             |
| Apoio ao raciocínio clínico        | Indireto                     | Direto                          |
| Observação do processo terapêutico | Limitada                     | Principal finalidade            |

---

## Um exemplo prático

Imagine uma pessoa atendida ao longo de seis meses.

Uma avaliação validada pode mostrar:

```text
PHQ-9

Sessão 1 = 18
Sessão 5 = 12
Sessão 10 = 7
```

Isso sugere redução dos sintomas depressivos.

Ao mesmo tempo, uma escala assistiva pode mostrar:

```text
Engajamento Terapêutico

Sessão 1 = Baixo
Sessão 5 = Moderado
Sessão 10 = Alto
```

Agora o profissional possui duas perspectivas diferentes:

* evolução dos sintomas
* evolução da participação no processo terapêutico

As duas informações são relevantes.

---

## O que uma avaliação validada não mostra?

Mesmo instrumentos muito úteis possuem limitações naturais.

Por exemplo:

Um PHQ-9 pode indicar redução dos sintomas depressivos.

Mas não informa:

* qualidade da aliança terapêutica
* risco de abandono
* adesão ao tratamento
* estágio do processo terapêutico
* percepção de evolução clínica

Esses aspectos podem exigir outras formas de observação.

---

## O que uma escala assistiva não mostra?

Da mesma forma, escalas assistivas não substituem avaliações científicas.

Elas não foram criadas para:

* rastrear sintomas específicos
* medir ansiedade
* medir depressão
* avaliar qualidade de vida
* realizar triagem clínica

Sua finalidade é diferente.

Elas complementam a observação clínica.

---

## Quando utilizar cada uma?

### Escalas Validadas

Mais indicadas quando o objetivo envolve:

* rastreamento
* monitoramento de sintomas
* qualidade de vida
* funcionalidade
* indicadores específicos

---

### Escalas Assistivas

Mais indicadas quando o objetivo envolve:

* acompanhamento longitudinal
* observação do processo terapêutico
* monitoramento do engajamento
* análise de risco de abandono
* direção clínica
* evolução do vínculo terapêutico

---

## A verdadeira força está na combinação

A maior riqueza clínica geralmente não surge de uma única fonte de informação.

Ela surge quando diferentes perspectivas podem ser observadas em conjunto.

Por exemplo:

```text
PHQ-9
↓
Engajamento Terapêutico
↓
Marcadores Clínicos
↓
Registros SOAP
↓
Histórico Longitudinal
↓
Leitura Evolutiva do Caso
```

Cada elemento contribui para ampliar a compreensão da trajetória clínica.

---

## Escalas Assistivas e Inteligência Clínica Longitudinal

As escalas assistivas foram desenvolvidas dentro de uma lógica de acompanhamento longitudinal.

Quando utilizadas em conjunto com avaliações validadas, registros clínicos e marcadores estruturados, podem contribuir para uma visão mais ampla da evolução do caso.

Essa integração é uma das bases da Inteligência Clínica Longitudinal.

---

## Conclusão

Escalas validadas e escalas assistivas não competem entre si.

Elas respondem a perguntas diferentes.

Enquanto avaliações científicas ajudam a observar sintomas, funcionalidade e qualidade de vida, escalas assistivas ajudam a acompanhar aspectos relacionados ao processo terapêutico e à evolução clínica.

Quando utilizadas de forma complementar, podem contribuir para uma compreensão mais ampla e longitudinal da trajetória da pessoa atendida.
