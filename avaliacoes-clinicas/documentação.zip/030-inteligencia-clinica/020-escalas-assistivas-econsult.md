---
sidebar_position: 20
title: Escalas Assistivas do eConsult
description: "Conheça as escalas assistivas do eConsult e entenda como elas podem apoiar o acompanhamento clínico longitudinal por meio da observação estruturada de aspectos relevantes do processo terapêutico."
---

# Escalas Assistivas do eConsult

***🧠 OBSERVAÇÃO CLÍNICA ESTRUTURADA PARA ACOMPANHAMENTO LONGITUDINAL***

A prática clínica envolve muito mais do que sintomas e diagnósticos.

Ao longo de um processo terapêutico, profissionais observam continuamente aspectos como:

* engajamento
* adesão
* participação
* aliança terapêutica
* evolução do caso
* fatores de risco
* mudanças comportamentais

Essas observações frequentemente influenciam decisões clínicas importantes.

No entanto, na maioria dos contextos, permanecem registradas apenas de forma narrativa ou subjetiva.

As **Escalas Assistivas do eConsult** foram desenvolvidas para apoiar a organização dessas observações ao longo do tempo, contribuindo para uma leitura mais estruturada da evolução clínica.

---

## O que são Escalas Assistivas?

Escalas Assistivas são instrumentos estruturados de observação clínica.

Seu objetivo não é realizar diagnósticos nem substituir avaliações científicas.

Elas foram criadas para auxiliar o profissional a registrar e acompanhar aspectos relevantes do processo terapêutico que normalmente são observados de forma qualitativa.

Em vez de medir sintomas específicos, essas escalas procuram organizar informações relacionadas à trajetória clínica.

---

## Uma proposta diferente das avaliações tradicionais

Avaliações científicas costumam responder perguntas como:

* Qual o nível atual de ansiedade?
* Existe sofrimento psicológico significativo?
* Como está a qualidade de vida?
* Existe risco relacionado ao uso de substâncias?

As Escalas Assistivas procuram responder perguntas diferentes:

* O paciente está engajado no processo?
* Existe risco de abandono?
* A direção clínica permanece favorável?
* Como está a aliança terapêutica?
* Em que estágio do processo terapêutico o caso se encontra?

Essas informações podem complementar avaliações clínicas e observações profissionais ao longo do acompanhamento.

---

## Principais Escalas Assistivas

### Engajamento Terapêutico (EC-ETE)

Auxilia na observação do nível de participação e envolvimento da pessoa atendida no processo terapêutico.

Pode contribuir para identificar:

* adesão às sessões
* participação ativa
* comprometimento com o processo
* continuidade do acompanhamento

---

### Risco de Abandono (EC-ERA)

Auxilia na identificação de sinais que podem indicar redução do vínculo com o processo terapêutico.

Pode contribuir para monitorar:

* faltas frequentes
* redução da participação
* afastamento gradual
* risco de interrupção do acompanhamento

---

### Aliança Terapêutica (EC-EAT)

Auxilia na observação da qualidade da relação terapêutica.

Pode incluir aspectos relacionados a:

* vínculo profissional
* confiança
* colaboração
* alinhamento de objetivos

---

### Direção Clínica (EC-EDC)

Auxilia na percepção estruturada da evolução do caso ao longo do tempo.

Pode apoiar a identificação de:

* evolução favorável
* estabilidade
* agravamento
* necessidade de revisão de estratégias

---

### Estágio do Processo Terapêutico (EC-EPT)

Auxilia na identificação do momento atual do acompanhamento.

Pode contribuir para compreender aspectos relacionados a:

* acolhimento inicial
* exploração clínica
* elaboração
* consolidação
* encerramento

---

### Risco Clínico Dinâmico (EC-ERC)

Auxilia na observação contínua de fatores clínicos que merecem atenção ao longo do acompanhamento.

Seu objetivo é apoiar a percepção de mudanças relevantes no contexto clínico.

---

## Por que estruturar observações clínicas?

A observação clínica faz parte da prática profissional.

Porém, quando essas observações permanecem apenas em registros narrativos, torna-se mais difícil identificar tendências ao longo do tempo.

A utilização de instrumentos estruturados pode facilitar:

* comparação entre momentos diferentes
* identificação de padrões
* visualização de tendências
* documentação clínica
* acompanhamento longitudinal

---

## Escalas Assistivas e Inteligência Clínica Longitudinal

As Escalas Assistivas foram concebidas para funcionar dentro de uma lógica de acompanhamento longitudinal.

Quando utilizadas de forma consistente ao longo do processo terapêutico, podem contribuir para uma compreensão mais ampla da evolução do caso.

Sua principal finalidade é apoiar a organização de informações clínicas relevantes que frequentemente não são capturadas por avaliações tradicionais.

---

## Escalas Assistivas e Avaliações Científicas

As Escalas Assistivas não substituem avaliações científicas.

Na prática, ambas podem desempenhar funções complementares.

### Avaliações Científicas

Auxiliam na observação de sintomas, funcionalidade, qualidade de vida e outros construtos específicos.

### Escalas Assistivas

Auxiliam na observação de aspectos relacionados ao processo terapêutico e à evolução clínica.

Quando analisadas em conjunto, podem contribuir para uma compreensão mais ampla da trajetória do caso.

---

## Aplicação em diferentes contextos clínicos

As Escalas Assistivas podem ser utilizadas em diferentes modalidades de acompanhamento.

### Terapia Individual

Monitoramento de engajamento, evolução clínica e continuidade do processo.

### Terapia de Casal

Observação de participação, vínculo e evolução do trabalho terapêutico.

### Terapia Familiar

Acompanhamento da dinâmica familiar e participação dos membros.

### Grupos Terapêuticos e Grupos de Escuta

Observação de engajamento, participação e evolução do processo grupal.

---

## Limitações e responsabilidade profissional

As Escalas Assistivas possuem finalidade assistiva.

Elas:

* não substituem avaliação clínica
* não realizam diagnósticos
* não produzem conclusões automáticas
* não substituem o julgamento profissional

Sua utilização deve ser compreendida como uma ferramenta complementar de organização e acompanhamento clínico.

---

## Conclusão

As Escalas Assistivas do eConsult foram desenvolvidas para apoiar a observação estruturada de aspectos relevantes do processo terapêutico.

Seu objetivo é contribuir para uma compreensão mais ampla da evolução clínica, favorecendo o acompanhamento longitudinal e a organização das informações observadas ao longo do tempo.

Mais do que medir sintomas, elas procuram apoiar a leitura da trajetória clínica.
