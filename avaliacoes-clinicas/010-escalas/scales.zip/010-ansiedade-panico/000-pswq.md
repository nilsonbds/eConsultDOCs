---
sidebar_position: 0
title: PSWQ - Escala Completa em PDF, Pontuação e Interpretação
description: "Baixe gratuitamente o PSWQ em PDF. Entenda como aplicar, calcular a pontuação e interpretar os resultados do Penn State Worry Questionnaire."
keywords:
  - PSWQ
  - PSWQ PDF
  - Penn State Worry Questionnaire
  - PSWQ interpretação
  - PSWQ pontuação
  - preocupação excessiva
  - preocupação patológica
  - ansiedade generalizada
  - avaliação de preocupação
---

# PSWQ: Escala Completa em PDF, Pontuação e Interpretação

O **PSWQ (Penn State Worry Questionnaire)** é uma das escalas mais utilizadas para avaliação da intensidade, frequência e incontrolabilidade das preocupações.

Desenvolvido por Meyer, Miller, Metzger e Borkovec, o instrumento tornou-se uma importante referência na avaliação clínica de preocupações excessivas, frequentemente associadas ao Transtorno de Ansiedade Generalizada (TAG).

Neste artigo você encontrará:

✅ O que é o PSWQ

✅ Como aplicar a escala

✅ Como calcular a pontuação

✅ Como interpretar os resultados

✅ Download gratuito do PSWQ em PDF

---

## Download Gratuito do PSWQ em PDF

Precisa aplicar o PSWQ em sua prática clínica?

👉 **[Baixar PSWQ em PDF](/pdf/scales/PSWQ.pdf)**

---

## O que é o PSWQ?

O Penn State Worry Questionnaire é um instrumento de autorrelato composto por 16 itens que avaliam a tendência de uma pessoa a se preocupar excessivamente.

A escala foi desenvolvida para medir características centrais da preocupação patológica, incluindo:

- Frequência das preocupações;
- Intensidade das preocupações;
- Dificuldade de controle;
- Persistência dos pensamentos preocupantes.

O instrumento é amplamente utilizado em pesquisas e em contextos clínicos relacionados à ansiedade.

---

## Para que serve o PSWQ?

O PSWQ pode ser utilizado para:

- Avaliação de preocupação excessiva;
- Rastreamento de sintomas relacionados ao TAG;
- Monitoramento clínico;
- Acompanhamento terapêutico;
- Estudos científicos sobre ansiedade;
- Avaliação da evolução do tratamento.

A escala não produz diagnóstico clínico, mas fornece indicadores relevantes sobre o padrão de preocupação do indivíduo.

---

## O que o PSWQ avalia?

O instrumento investiga aspectos centrais da preocupação crônica.

Entre eles:

- Preocupação persistente;
- Dificuldade para interromper pensamentos preocupantes;
- Sensação de perda de controle sobre as preocupações;
- Tendência a antecipar problemas;
- Preocupação excessiva com situações cotidianas.

Diferentemente de outras escalas de ansiedade, o foco principal do PSWQ não são os sintomas físicos da ansiedade, mas sim o processo cognitivo da preocupação.

---

## Como funciona a pontuação do PSWQ?

Cada item é respondido em uma escala de 1 a 5 pontos.

| Resposta | Pontuação |
|-----------|-----------|
| Nada típico de mim | 1 |
| Pouco típico de mim | 2 |
| Moderadamente típico de mim | 3 |
| Muito típico de mim | 4 |
| Extremamente típico de mim | 5 |

Alguns itens possuem pontuação invertida.

Os itens reversos são:

- Item 1
- Item 3
- Item 8
- Item 10
- Item 11

A soma total produz um escore entre **16 e 80 pontos**.

---

## Como interpretar os resultados do PSWQ?

Uma interpretação frequentemente utilizada considera:

| Escore | Interpretação |
|----------|----------|
| 16 – 39 | Nível baixo de preocupação |
| 40 – 59 | Nível moderado de preocupação |
| 60 – 80 | Nível elevado de preocupação |

Escores mais altos indicam maior intensidade e persistência de preocupações.

Os resultados devem ser interpretados juntamente com a avaliação clínica realizada pelo profissional.

---

## O verdadeiro valor do PSWQ está na evolução dos resultados

Uma única aplicação mostra apenas o nível atual de preocupação do paciente.

Aplicações sucessivas permitem identificar:

- Redução das preocupações ao longo do tratamento;
- Persistência de padrões cognitivos disfuncionais;
- Resposta às intervenções terapêuticas;
- Tendências de melhora ou agravamento.

<!--
![Exemplo de acompanhamento longitudinal de escalas psicológicas no eConsult](#)

*Exemplo ilustrativo de acompanhamento longitudinal utilizando aplicações sucessivas de escalas psicológicas. A visualização da evolução dos resultados auxilia na identificação de tendências clínicas e na tomada de decisão ao longo do tratamento.*
-->

👉 Veja também: [Dados isolados vs leitura evolutiva do caso](../../050-comparativos/050-dados-isolados-vs-leitura-evolutiva-do-caso.md)

---

## Quando aplicar o PSWQ?

### Avaliação inicial

Para identificar níveis de preocupação excessiva.

### Monitoramento clínico

Para acompanhar mudanças ao longo do tratamento.

### Intervenções focadas em ansiedade

Como apoio à avaliação da resposta terapêutica.

### Pesquisas científicas

Por sua ampla utilização em estudos relacionados ao TAG.

---

## Vantagens do PSWQ

- Forte respaldo científico;
- Aplicação simples;
- Fácil interpretação;
- Excelente para avaliação de preocupação excessiva;
- Ampla utilização internacional;
- Útil para monitoramento longitudinal.

---

## Limitações do PSWQ

- Não produz diagnóstico clínico;
- Baseia-se em autorrelato;
- Avalia principalmente preocupação, e não todos os aspectos da ansiedade;
- Deve ser interpretado juntamente com avaliação clínica.

---

## Download do PSWQ em PDF

👉 **[Baixar PSWQ em PDF](/pdf/scales/PSWQ.pdf)**

---

## Como o eConsult auxilia no acompanhamento clínico

O padrão de preocupação de um paciente pode mudar significativamente ao longo do tratamento.

Com o eConsult você pode:

- Aplicar escalas periodicamente;
- Registrar resultados automaticamente;
- Visualizar gráficos de evolução;
- Utilizar marcadores clínicos;
- Comparar resultados entre diferentes períodos;
- Integrar escalas ao prontuário eletrônico.

👉 **Conheça o Sistema Clínico Longitudinal para Psicólogos:** https://econsult.app.br/sistema-clinico-longitudinal-psicologo

---

## Perguntas Frequentes sobre o PSWQ

### O PSWQ faz diagnóstico de ansiedade?

Não. O PSWQ é uma ferramenta de avaliação e monitoramento.

### Qual a pontuação máxima do PSWQ?

A pontuação máxima é de 80 pontos.

### O PSWQ é gratuito?

Sim. O instrumento é amplamente utilizado em pesquisas e contextos clínicos.

### Existe versão do PSWQ em PDF?

Sim. Você pode disponibilizar a escala em PDF para download neste artigo.

### Qual a diferença entre PSWQ e GAD-7?

O GAD-7 avalia sintomas gerais de ansiedade. O PSWQ é focado especificamente na intensidade e no controle das preocupações.

### O PSWQ é útil para TAG?

Sim. O instrumento é amplamente utilizado em estudos e avaliações relacionadas ao Transtorno de Ansiedade Generalizada.

:::tip Veja também outras escalas de triagem geral:

👉 [**PHQ-9**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/000-triagem-geral/000-phq-9.md)

👉 [**GAD-7**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/000-triagem-geral/010-gad-7.md)

👉 [**DASS-21**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/000-triagem-geral/040-dass-21.md)

👉 [**K10**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/000-triagem-geral/030-k10.md)

👉 [**SRQ-20**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/000-triagem-geral/020-srq-20.md)

:::

---

## Artigos Relacionados

👉 [Quando aplicar avaliações psicológicas](../../040-guias/000-quando-aplicar-avaliacoes.md)

👉 [Como escolher uma escala psicológica](../../040-guias/010-como-escolher-uma-escala.md)

👉 [Interpretação de resultados](../../040-guias/020-interpretacao-de-resultados.md)

👉 [Observação clínica vs observação estruturada](../../050-comparativos/040-observacao-clinica-vs-observacao-estruturada.md)

👉 [Dados isolados vs leitura evolutiva do caso](../../050-comparativos/050-dados-isolados-vs-leitura-evolutiva-do-caso.md)

👉 [Sugestão inteligente de avaliações](../../030-inteligencia-clinica/040-sugestao-inteligente-de-avaliacoes.md)

👉 [Leitura evolutiva do caso](../../030-inteligencia-clinica/030-leitura-evolutiva-do-caso.md)

---

## Referências

MEYER, T. J.; MILLER, M. L.; METZGER, R. L.; BORKOVEC, T. D. *Development and validation of the Penn State Worry Questionnaire*. Behaviour Research and Therapy, 1990.

CAMCOPS Documentation. *Penn State Worry Questionnaire (PSWQ)*.

Observação técnica: instrumento de 16 itens com respostas de 1 a 5. Os itens 1, 3, 8, 10 e 11 possuem pontuação reversa.