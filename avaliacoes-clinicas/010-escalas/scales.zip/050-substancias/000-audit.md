---
sidebar_position: 0
title: AUDIT - Escala Completa em PDF, Pontuação e Interpretação
description: "Baixe gratuitamente o AUDIT em PDF. Entenda como aplicar, calcular a pontuação e interpretar os resultados do Alcohol Use Disorders Identification Test."
keywords:
  - AUDIT
  - AUDIT PDF
  - Alcohol Use Disorders Identification Test
  - AUDIT interpretação
  - AUDIT pontuação
  - alcoolismo
  - dependência alcoólica
  - consumo de álcool
  - uso nocivo de álcool
---

# AUDIT: Escala Completa em PDF, Pontuação e Interpretação

O **AUDIT (Alcohol Use Disorders Identification Test)** é uma das escalas mais utilizadas no mundo para rastreamento de padrões de consumo de álcool.

Desenvolvido pela Organização Mundial da Saúde (OMS), o instrumento permite identificar desde o consumo de risco até possíveis quadros de dependência alcoólica.

Neste artigo você encontrará:

✅ O que é o AUDIT

✅ Como aplicar a escala

✅ Como calcular a pontuação

✅ Como interpretar os resultados

✅ Download gratuito do AUDIT em PDF

---

## Download Gratuito do AUDIT em PDF

Precisa aplicar o AUDIT em sua prática clínica?

👉 **[Baixar AUDIT em PDF](/pdf/scales/AUDIT.pdf)**

---

## O que é o AUDIT?

O AUDIT é um instrumento de rastreamento composto por 10 perguntas relacionadas ao padrão de consumo de bebidas alcoólicas nos últimos 12 meses.

O questionário foi desenvolvido pela Organização Mundial da Saúde para auxiliar na identificação precoce de comportamentos relacionados ao uso problemático de álcool.

O instrumento é amplamente utilizado em:

- Psicologia;
- Psiquiatria;
- Medicina;
- Atenção primária à saúde;
- Saúde ocupacional;
- Pesquisas científicas.

---

## Para que serve o AUDIT?

O AUDIT pode ser utilizado para:

- Identificação de consumo de risco;
- Rastreamento de uso nocivo de álcool;
- Identificação de provável dependência alcoólica;
- Monitoramento clínico;
- Avaliação da resposta ao tratamento;
- Produção de indicadores objetivos de acompanhamento.

A escala não substitui avaliação clínica especializada.

---

## O que o AUDIT avalia?

O instrumento investiga três grandes áreas.

### Padrão de consumo

Avalia:

- Frequência do consumo;
- Quantidade ingerida;
- Episódios de consumo excessivo.

### Sintomas de dependência

Avalia:

- Dificuldade de interromper o consumo;
- Necessidade de beber pela manhã;
- Perda de controle.

### Consequências do consumo

Avalia:

- Culpa ou remorso;
- Amnésia alcoólica;
- Prejuízos funcionais;
- Acidentes relacionados ao álcool;
- Preocupação de familiares ou profissionais.

---

## Como funciona a pontuação do AUDIT?

Cada item recebe pontuação entre 0 e 4 pontos.

A soma dos 10 itens gera um escore total entre:

**0 e 40 pontos**

Quanto maior a pontuação, maior o risco associado ao consumo de álcool.

---

## Como interpretar os resultados do AUDIT?

| Escore | Interpretação |
|----------|----------|
| 0 – 7 | Consumo de risco baixo |
| 8 – 15 | Consumo de risco |
| 16 – 19 | Uso nocivo |
| 20 – 40 | Provável dependência alcoólica |

Pontuações mais elevadas indicam necessidade de investigação clínica mais aprofundada.

---

## O que significa uma pontuação elevada no AUDIT?

Escores elevados podem estar associados a:

- Consumo excessivo de álcool;
- Perda de controle sobre o consumo;
- Impactos negativos na vida pessoal;
- Problemas ocupacionais;
- Problemas familiares;
- Dependência alcoólica.

A interpretação deve sempre considerar a avaliação clínica global.

---

## O verdadeiro valor do AUDIT está na evolução dos resultados

Uma única aplicação mostra apenas o padrão atual de consumo.

Aplicações sucessivas permitem identificar:

- Redução do consumo;
- Mudanças no padrão de risco;
- Resposta às intervenções;
- Evolução clínica;
- Possíveis recaídas.

<!--
![Acompanhamento longitudinal do consumo de álcool no eConsult](#)

*Exemplo ilustrativo de monitoramento longitudinal do consumo de álcool utilizando aplicações sucessivas do AUDIT.*
-->

### O que observar no AUDIT?

A evolução dos escores permite acompanhar a trajetória do paciente ao longo do tratamento.

Por exemplo:

- Redução gradual do risco;
- Estabilização do padrão de consumo;
- Oscilações associadas a eventos de vida;
- Indícios precoces de recaída.

👉 Veja também: [Dados isolados vs leitura evolutiva do caso](../../050-comparativos/050-dados-isolados-vs-leitura-evolutiva-do-caso.md)

---

## Quando aplicar o AUDIT?

### Avaliação inicial

Para identificar padrões de consumo de álcool.

### Monitoramento clínico

Para acompanhar mudanças ao longo do tratamento.

### Saúde ocupacional

Como instrumento de rastreamento.

### Programas de prevenção

Para identificação precoce de fatores de risco.

---

## Vantagens do AUDIT

- Forte respaldo científico;
- Desenvolvido pela OMS;
- Fácil aplicação;
- Excelente sensibilidade para consumo de risco;
- Amplamente utilizado internacionalmente;
- Útil para monitoramento clínico.

---

## Limitações do AUDIT

- Baseia-se em autorrelato;
- Não produz diagnóstico clínico;
- Pode sofrer influência de subnotificação;
- Deve ser interpretado juntamente com avaliação profissional.

---

## Download do AUDIT em PDF

👉 **[Baixar AUDIT em PDF](/pdf/scales/AUDIT.pdf)**

---

## Como o eConsult auxilia no acompanhamento clínico

O padrão de consumo de álcool pode variar significativamente ao longo do acompanhamento.

Com o eConsult você pode:

- Aplicar escalas periodicamente;
- Registrar resultados automaticamente;
- Visualizar gráficos de evolução;
- Utilizar marcadores clínicos;
- Integrar escalas ao prontuário eletrônico;
- Acompanhar tendências clínicas longitudinalmente.

👉 **Conheça o Sistema Clínico Longitudinal para Psicólogos:** https://econsult.app.br/sistema-clinico-longitudinal-psicologo

---

## Perguntas Frequentes sobre o AUDIT

### O AUDIT faz diagnóstico de alcoolismo?

Não. O AUDIT é uma ferramenta de rastreamento.

### Qual a pontuação máxima do AUDIT?

A pontuação máxima é de 40 pontos.

### Qual o ponto de corte mais utilizado?

Pontuações iguais ou superiores a 8 geralmente indicam consumo de risco.

### Existe versão do AUDIT em PDF?

Sim. Você pode disponibilizar a escala em PDF para download neste artigo.

### O AUDIT é validado para o Brasil?

Sim. Existem estudos brasileiros avaliando suas propriedades psicométricas.

### Qual a diferença entre AUDIT e CAGE?

O AUDIT avalia frequência, quantidade, consequências e sintomas relacionados ao álcool. O CAGE é uma triagem muito mais breve, composta por apenas quatro perguntas.

:::tip Veja também outras escalas relacionadas ao uso de substâncias:

👉 [**CAGE**: Escala Completa em PDF, Pontuação e Interpretação](../050-substancias/010-cage.md)

👉 [**DAST-10**: Escala Completa em PDF, Pontuação e Interpretação](../050-substancias/020-dast-10.md)

:::

---

## Artigos Relacionados

👉 [Quando aplicar avaliações psicológicas](../../040-guias/000-quando-aplicar-avaliacoes.md)

👉 [Como escolher uma escala psicológica](../../040-guias/010-como-escolher-uma-escala.md)

👉 [Interpretação de resultados](../../040-guias/020-interpretacao-de-resultados.md)

👉 [Observação clínica vs observação estruturada](../../050-comparativos/040-observacao-clinica-vs-observacao-estruturada.md)

👉 [Dados isolados vs leitura evolutiva do caso](../../050-comparativos/050-dados-isolados-vs-leitura-evolutiva-do-caso.md)

👉 [Sugestão inteligente de avaliações](../../030-inteligencia-clinica/040-sugestao-inteligente-de-avaliacoes.md)

👉 [Leitura evolutiva do caso](../../030-inteligencia-clinica/030-leitura-evolutiva-do-caso.md)

---

## Referências

SAUNDERS, J. B.; AASLAND, O. G.; BABOR, T. F.; DE LA FUENTE, J. R.; GRANT, M. *Development of the Alcohol Use Disorders Identification Test (AUDIT): WHO Collaborative Project on Early Detection of Persons with Harmful Alcohol Consumption-II*. Addiction, 1993.

WORLD HEALTH ORGANIZATION. *AUDIT: The Alcohol Use Disorders Identification Test. Guidelines for Use in Primary Care*. Geneva: WHO, 2001.

LIMA, C. T.; FREIRE, A. C.; SILVA, A. P. B.; et al. *Concurrent and construct validity of the AUDIT in an urban Brazilian sample*. Alcohol and Alcoholism, 2005.