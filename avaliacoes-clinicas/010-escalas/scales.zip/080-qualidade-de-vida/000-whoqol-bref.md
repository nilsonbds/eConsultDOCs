---
sidebar_position: 0
title: WHOQOL-BREF - Escala Completa em PDF, Pontuação e Interpretação
description: "Baixe gratuitamente o WHOQOL-BREF em PDF. Entenda como aplicar, calcular os domínios e interpretar os resultados da avaliação de qualidade de vida da OMS."
keywords:
  - WHOQOL-BREF
  - WHOQOL-BREF PDF
  - qualidade de vida
  - WHOQOL interpretação
  - WHOQOL pontuação
  - qualidade de vida OMS
  - WHOQOL Brasil
  - avaliação de qualidade de vida
---

# WHOQOL-BREF: Escala Completa em PDF, Pontuação e Interpretação

O **WHOQOL-BREF (World Health Organization Quality of Life - Bref)** é um dos instrumentos mais utilizados no mundo para avaliação da qualidade de vida.

Desenvolvido pela Organização Mundial da Saúde (OMS), ele permite avaliar como a pessoa percebe sua própria vida em quatro áreas fundamentais:

- Saúde física
- Bem-estar psicológico
- Relações sociais
- Meio ambiente

Neste artigo você encontrará:

✅ Download gratuito do WHOQOL-BREF em PDF

✅ Como aplicar a escala

✅ Como calcular os domínios

✅ Como interpretar os resultados

✅ Exemplo de acompanhamento longitudinal

---

## Download Gratuito do WHOQOL-BREF em PDF

👉 **[Baixar WHOQOL-BREF em PDF](/pdf/scales/WHOQOL-BREF.pdf)**

---

## O que é o WHOQOL-BREF?

O WHOQOL-BREF é a versão abreviada do WHOQOL-100, criada pela Organização Mundial da Saúde para avaliar a percepção subjetiva da qualidade de vida.

Possui 26 questões e investiga aspectos físicos, psicológicos, sociais e ambientais relacionados ao bem-estar da pessoa nas últimas duas semanas.

É amplamente utilizado em:

- Psicologia
- Psiquiatria
- Medicina
- Saúde Mental
- Reabilitação
- Pesquisas científicas

---

## O que o WHOQOL-BREF avalia?

O instrumento produz quatro domínios independentes.

### Domínio Físico

Avalia:

- Energia e fadiga
- Dor e desconforto
- Sono e repouso
- Mobilidade
- Capacidade de trabalho

### Domínio Psicológico

Avalia:

- Autoestima
- Sentimentos positivos
- Sentido de vida
- Concentração
- Emoções negativas

### Relações Sociais

Avalia:

- Relacionamentos pessoais
- Apoio social
- Vida afetiva

### Meio Ambiente

Avalia:

- Segurança
- Recursos financeiros
- Lazer
- Transporte
- Serviços de saúde
- Condições de moradia



<div style={{
  overflowX: "auto",
  whiteSpace: "nowrap",
  paddingBottom: "8px"
}}>
  <img 
    src="/img/avaliacoes-clinicas/dominios-do-whoqol.png" 
    alt="Os quatro domínios do WHOQOL-BREF" 
    style={{
      display: "inline-block",
      maxWidth: "none",
      height: "600px",
      borderRadius: "8px",
      marginBottom: "10px"
    }} 
  />
</div>

*Os quatro pilares avaliados pelo WHOQOL-BREF: Saúde Física, Bem-estar Psicológico, Relações Sociais e Meio Ambiente.*

---

## Como funciona a pontuação?

Cada questão recebe pontuação de 1 a 5.

Os resultados são agrupados por domínio.

Diferentemente de escalas como PHQ-9 ou GAD-7, o foco principal não é um escore único, mas a análise das diferentes dimensões da qualidade de vida.

---

## Como interpretar os resultados?

### Qualidade de Vida Física

| Escore | Interpretação |
|---------|---------|
| 4 – 9,9 | Baixa |
| 10 – 14,9 | Moderada |
| 15 – 20 | Alta |

### Qualidade de Vida Psicológica

| Escore | Interpretação |
|---------|---------|
| 4 – 9,9 | Baixa |
| 10 – 14,9 | Moderada |
| 15 – 20 | Alta |

### Qualidade de Vida Social

| Escore | Interpretação |
|---------|---------|
| 4 – 9,9 | Baixa |
| 10 – 14,9 | Moderada |
| 15 – 20 | Alta |

### Qualidade de Vida Ambiental

| Escore | Interpretação |
|---------|---------|
| 4 – 9,9 | Baixa |
| 10 – 14,9 | Moderada |
| 15 – 20 | Alta |

---

## O verdadeiro valor do WHOQOL-BREF está no perfil multidimensional

Uma pessoa pode apresentar:

- Qualidade de vida física alta
- Qualidade de vida psicológica baixa
- Relações sociais preservadas
- Meio ambiente comprometido

Por isso a análise por domínios costuma ser muito mais útil do que um escore geral.

<!--
![Perfil multidimensional do WHOQOL-BREF](#)

*Exemplo ilustrativo do perfil de qualidade de vida por domínio.*
-->

---

## O verdadeiro valor do WHOQOL-BREF está na evolução longitudinal

Uma aplicação isolada mostra apenas uma fotografia do momento atual.

Aplicações sucessivas permitem identificar:

- Melhora após psicoterapia
- Impacto de intervenções médicas
- Mudanças em relacionamentos
- Alterações na percepção da qualidade de vida
- Ganhos em áreas específicas do funcionamento

<!--
![Evolução longitudinal do WHOQOL-BREF](#)

*Exemplo ilustrativo da evolução dos domínios ao longo do acompanhamento.*
-->

### O que observar na evolução?

Nem sempre todos os domínios evoluem ao mesmo tempo.

Por exemplo:

- O domínio psicológico pode melhorar antes do físico;
- Relações sociais podem permanecer estáveis enquanto a qualidade ambiental melhora;
- Ganhos clínicos podem ocorrer sem mudanças imediatas na percepção global da qualidade de vida.

Por isso a análise longitudinal costuma fornecer informações mais relevantes do que uma única aplicação.

👉 Veja também: [Leitura evolutiva do caso](../../030-inteligencia-clinica/030-leitura-evolutiva-do-caso.md)

---

## WHOQOL-BREF ou WHODAS 2.0?

| Característica | WHOQOL-BREF | WHODAS 2.0 |
|---------|---------|---------|
| Avalia qualidade de vida | ✅ | ❌ |
| Avalia funcionalidade | ❌ | ✅ |
| Foco subjetivo | ✅ | Parcial |
| Foco em incapacidade | ❌ | ✅ |

São instrumentos complementares.

Enquanto o WHOQOL-BREF avalia a percepção de qualidade de vida, o WHODAS 2.0 mede funcionalidade e incapacidade.

---

## Quando aplicar o WHOQOL-BREF?

### Avaliação inicial

Para compreender a percepção global do paciente sobre sua vida.

### Planejamento terapêutico

Para identificar áreas mais comprometidas.

### Acompanhamento clínico

Para monitorar mudanças ao longo do tratamento.

### Alta terapêutica

Para avaliar ganhos percebidos pelo paciente.

---

## Vantagens do WHOQOL-BREF

- Aplicação relativamente rápida;
- Forte respaldo científico internacional;
- Avaliação multidimensional;
- Fácil interpretação;
- Permite acompanhamento longitudinal;
- Aplicável em diferentes contextos clínicos.

---

## Limitações do WHOQOL-BREF

- Não realiza diagnóstico;
- Baseado em autorrelato;
- Influenciado por fatores culturais e contextuais;
- Deve ser interpretado em conjunto com avaliação clínica.

---

## Download do WHOQOL-BREF em PDF

👉 **[Baixar WHOQOL-BREF em PDF](/pdf/scales/WHOQOL-BREF.pdf)**

---

## Como o eConsult auxilia no acompanhamento da qualidade de vida

O verdadeiro valor do WHOQOL-BREF surge quando os resultados são analisados ao longo do tempo.

Com o eConsult você pode:

- Aplicar o WHOQOL-BREF periodicamente;
- Visualizar os quatro domínios separadamente;
- Comparar aplicações;
- Gerar gráficos evolutivos;
- Integrar resultados ao prontuário eletrônico;
- Identificar tendências clínicas automaticamente.

👉 **Conheça o Sistema Clínico Longitudinal para Psicólogos:** https://econsult.app.br/sistema-clinico-longitudinal-psicologo

---

## Perguntas Frequentes sobre o WHOQOL-BREF

### O WHOQOL-BREF faz diagnóstico?

Não. O instrumento avalia percepção de qualidade de vida.

### Quantas perguntas possui?

O WHOQOL-BREF possui 26 questões.

### O WHOQOL-BREF possui escore total?

O foco principal é a análise dos quatro domínios.

### Qual a diferença entre WHOQOL-BREF e WHODAS 2.0?

WHOQOL-BREF avalia qualidade de vida percebida. WHODAS 2.0 avalia funcionalidade e incapacidade.

### Existe versão em PDF?

Sim. Você pode disponibilizar a escala para download neste artigo.

:::tip Veja também outras escalas de qualidade de vida:

👉 [**SWLS**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/080-qualidade-de-vida/010-swls.md)

👉 [**RSES**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/080-qualidade-de-vida/020-rses.md)

👉 [**GSE**: Escala Completa em PDF, Pontuação e Interpretação](../../010-escalas/080-qualidade-de-vida/030-gse.md)

:::

---

## Artigos Relacionados

👉 [Quando aplicar avaliações psicológicas](../../040-guias/000-quando-aplicar-avaliacoes.md)

👉 [Como escolher uma escala psicológica](../../040-guias/010-como-escolher-uma-escala.md)

👉 [Interpretação de resultados](../../040-guias/020-interpretacao-de-resultados.md)

👉 [Observação clínica vs observação estruturada](../../050-comparativos/040-observacao-clinica-vs-observacao-estruturada.md)

👉 [Dados isolados vs leitura evolutiva do caso](../../050-comparativos/050-dados-isolados-vs-leitura-evolutiva-do-caso.md)

👉 [Sugestão inteligente de avaliações](../../030-inteligencia-clinica/040-sugestao-inteligente-de-avaliacoes.md)

👉 [Leitura evolutiva do caso](../../030-inteligencia-clinica/030-leitura-evolutiva-do-caso.md)

---

## Referências

WHOQOL GROUP. Development of the World Health Organization WHOQOL-BREF quality of life assessment. Psychological Medicine, 1998.

FLECK, M. P. A.; et al. Aplicação da versão em português do instrumento abreviado de avaliação da qualidade de vida "WHOQOL-BREF". Revista de Saúde Pública, 2000.